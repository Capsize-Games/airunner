"""HTTP client used by AIRunner clients to launch or connect to the daemon."""

from __future__ import annotations

import base64
import json
import os
import signal
import subprocess
import time
from pathlib import Path
from typing import TYPE_CHECKING
from typing import Any, Callable, Dict, Iterable, List, Optional
from urllib.parse import urlencode

import requests

from airunner_services.runtimes.daemon_config import DaemonConfig
from airunner_services.daemon_connection_state import (
    DaemonConnectionState,
)
from airunner_services.daemon_client.gui_bridge_mixin import GuiBridgeMixin
from airunner_services.daemon_client.launcher import DaemonLauncher
from airunner_services.api.loopback_token import (
    get_or_create_loopback_token,
)
from airunner_common.dev_build_token import current_dev_build_token
from airunner_common.contract_enums import LLMActionType, SignalCode
from airunner_common.contract_version import (
    CONTRACT_VERSION,
    is_compatible_contract_version,
)
from airunner_common.settings import AIRUNNER_LOG_LEVEL

if TYPE_CHECKING:
    # The service-owned LLMRequest dataclass pulls in the database layer,
    # which (transitively) imports torch at module import time. The GUI
    # package deliberately keeps torch optional, so this import must stay
    # lazy: daemon-client consumers only use duck-typed request objects
    # (to_dict()/attributes), never the service class itself (issue #2037).
    from airunner_services.llm.llm_request import LLMRequest

# get_logger is imported from its leaf module (not the utils.application
# package __init__) so that importing the daemon client does not transitively
# import torch via the application utility package (issue #2037).
from airunner_services.utils.application.get_logger import get_logger

StateCallback = Callable[[DaemonConnectionState, str], None]
_ART_JOB_POLL_INTERVAL_SECONDS = 0.10


class GuiDaemonClient(GuiBridgeMixin):
    """Start, connect to, and communicate with the local daemon."""

    def __init__(
        self,
        config_path: Optional[Path] = None,
        *,
        launcher: Optional[DaemonLauncher] = None,
        session: Optional[requests.Session] = None,
        auto_start: bool = True,
        startup_timeout_seconds: float = 20.0,
        poll_interval_seconds: float = 0.25,
        request_timeout_seconds: float = 30.0,
        detect_stale_dev_daemon: bool = False,
        state_callback: Optional[StateCallback] = None,
        signal_emitter: Optional[
            Callable[[Any, Dict[str, Any]], None]
        ] = None,
        time_fn: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.config = DaemonConfig(config_path)
        self._launcher = launcher or DaemonLauncher(self.config.config_path)
        self._session = session or requests.Session()
        self._auto_start = auto_start
        self._startup_timeout_seconds = startup_timeout_seconds
        self._poll_interval_seconds = poll_interval_seconds
        self._request_timeout_seconds = request_timeout_seconds
        self._detect_stale_dev_daemon = detect_stale_dev_daemon
        self._state_callback = state_callback
        self._time_fn = time_fn
        self._sleep = sleep
        self._state = DaemonConnectionState.NOT_STARTED
        self._last_error = ""
        self._loopback_token = get_or_create_loopback_token()
        self._dev_build_token_checked_at = 0.0
        self._cached_dev_build_token: Optional[str] = None
        self._missing_dev_build_token_logged = False
        self._emit = signal_emitter or self._noop_emitter
        self.logger = get_logger(__name__, AIRUNNER_LOG_LEVEL)

    @property
    def state(self) -> DaemonConnectionState:
        """Return the current daemon connection state."""
        return self._state

    @property
    def last_error(self) -> str:
        """Return the most recent daemon connection or request error."""
        return self._last_error

    @property
    def base_url(self) -> str:
        """Return the configured daemon base URL."""
        server = self.config.config.get("server", {})
        host = server.get("host", "127.0.0.1")
        port = server.get("port", 8188)
        return f"http://{host}:{port}"

    def ensure_connected(self, *, auto_start: Optional[bool] = None) -> bool:
        """Return True when the daemon is reachable, starting it when allowed."""
        health = self._healthcheck_payload()
        mismatch = self._contract_version_mismatch_reason(health)
        if mismatch is not None:
            # Not a stale-daemon condition: recycling a genuinely
            # incompatible daemon build fixes nothing (issue #2192).
            self._last_error = mismatch
            self._set_state(DaemonConnectionState.FAILED, mismatch)
            return False

        stale_reason = self._stale_dev_daemon_reason(health)
        if health is not None and stale_reason is None:
            self._set_state(DaemonConnectionState.CONNECTED, "connected")
            return True

        if stale_reason is not None:
            if not self._resolved_auto_start(auto_start):
                self._set_state(
                    DaemonConnectionState.DISCONNECTED,
                    stale_reason,
                )
                return False
            if not self._recycle_stale_daemon(stale_reason):
                return False

        if not self._resolved_auto_start(auto_start):
            self._set_state(
                DaemonConnectionState.DISCONNECTED,
                self._last_error or "daemon unavailable",
            )
            return False

        self._prepare_connection_attempt()
        try:
            self._launcher.start()
        except OSError as exc:
            self._last_error = str(exc)
            self._set_state(DaemonConnectionState.FAILED, self._last_error)
            return False
        return self._wait_until_ready()

    def reconnect(self) -> bool:
        """Force a reconnect attempt to the daemon."""
        self._set_state(DaemonConnectionState.RECONNECTING, "reconnecting")
        return self.ensure_connected(auto_start=True)

    def disconnect(self, *, stop_process: bool = False) -> None:
        """Mark the daemon disconnected and optionally stop the process."""
        if stop_process:
            self._launcher.stop()
        self._set_state(DaemonConnectionState.DISCONNECTED, "disconnected")

    def health_check(self) -> Dict[str, Any]:
        """Return the daemon health payload."""
        response = self._request("GET", "/health", auto_start=False)
        return response.json()

    def is_available(self, *, timeout_seconds: float = 0.2) -> bool:
        """Return True when the daemon is already reachable."""
        health = self._healthcheck_payload(timeout_seconds=timeout_seconds)
        mismatch = self._contract_version_mismatch_reason(health)
        if mismatch is not None:
            self._last_error = mismatch
            self._set_state(DaemonConnectionState.FAILED, mismatch)
            return False

        stale_reason = self._stale_dev_daemon_reason(health)
        if health is not None and stale_reason is None:
            self._set_state(DaemonConnectionState.CONNECTED, "connected")
            return True

        if stale_reason is not None:
            self._last_error = stale_reason
        self._set_state(
            DaemonConnectionState.DISCONNECTED,
            self._last_error or "daemon unavailable",
        )
        return False

    def interrupt_llm(self) -> Dict[str, Any]:
        """Interrupt the active daemon-side LLM request."""
        response = self._request(
            "POST",
            "/admin/interrupt",
            json_payload={"kind": "process"},
            auto_start=False,
        )
        return response.json()

    def unload_local_llm(
        self,
        *,
        auto_start: bool = False,
        timeout_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Interrupt and queue unload for the daemon's local-worker LLM."""
        response = self._request(
            "POST",
            "/admin/llm/unload",
            auto_start=auto_start,
            timeout_seconds=timeout_seconds,
        )
        return response.json()

    def daemon_runtime_status(
        self,
        *,
        auto_start: bool = False,
        timeout_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Return combined daemon lifecycle and runtime status."""
        response = self._request(
            "GET",
            "/api/v1/daemon/status",
            auto_start=auto_start,
            timeout_seconds=timeout_seconds,
        )
        return response.json()

    def runtime_status(
        self,
        runtime_name: str,
        *,
        provider: str = "local",
        deployment_mode: str = "default",
        auto_start: bool = False,
    ) -> Dict[str, Any]:
        """Return the daemon summary for one runtime route."""
        query = urlencode(
            {
                "provider": provider,
                "deployment_mode": deployment_mode,
            }
        )
        response = self._request(
            "GET",
            f"/api/v1/daemon/runtimes/{runtime_name}?{query}",
            auto_start=auto_start,
        )
        return response.json()

    def wait_runtime_ready(
        self,
        runtime_name: str,
        *,
        loaded: bool,
        provider: str = "local",
        deployment_mode: str = "default",
        auto_start: bool = False,
        timeout_seconds: float = 30.0,
    ) -> bool:
        """Poll one runtime summary until it reaches the requested state."""
        deadline = self._time_fn() + timeout_seconds
        while self._time_fn() < deadline:
            try:
                summary = self.runtime_status(
                    runtime_name,
                    provider=provider,
                    deployment_mode=deployment_mode,
                    auto_start=auto_start,
                )
            except RuntimeError:
                self._sleep(self._poll_interval_seconds)
                continue
            if self._runtime_matches(summary, loaded):
                return True
            self._sleep(self._poll_interval_seconds)
        return False

    def cancel_runtime(
        self,
        runtime_name: str,
        *,
        provider: str = "local",
        deployment_mode: str = "default",
        request_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        auto_start: bool = False,
        timeout_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Cancel one runtime request through the daemon control API."""
        return self._runtime_action(
            runtime_name,
            "cancel",
            provider=provider,
            deployment_mode=deployment_mode,
            request_id=request_id,
            metadata=metadata,
            auto_start=auto_start,
            timeout_seconds=timeout_seconds,
        )

    def synthesize_tts(
        self,
        text: str,
        *,
        voice: Optional[str] = None,
        speed: float = 1.0,
        model: Optional[str] = None,
        model_type: Optional[str] = None,
        request_id: Optional[str] = None,
        auto_start: bool = True,
    ) -> bytes:
        """Synthesize one TTS utterance through the daemon TTS route."""
        response = self._request(
            "POST",
            "/api/v1/tts/synthesize",
            json_payload={
                "text": text,
                "voice": voice,
                "speed": speed,
                "model": model,
                "model_type": model_type,
                "request_id": request_id,
            },
            auto_start=auto_start,
            timeout_seconds=120.0,
        )
        return response.content

    def start_art_generation(
        self,
        *,
        prompt: str,
        negative_prompt: str = "",
        width: int = 1024,
        height: int = 1024,
        steps: int = 20,
        cfg_scale: float = 7.5,
        seed: Optional[int] = None,
        num_images: int = 1,
        model: Optional[str] = None,
        version: Optional[str] = None,
        scheduler: Optional[str] = None,
        pipeline: Optional[str] = None,
        strength: Optional[float] = None,
        image_b64: Optional[str] = None,
        skip_auto_export: bool = False,
        auto_start: bool = True,
    ) -> Dict[str, Any]:
        """Submit one art generation request through the daemon art route."""
        self.logger.info(
            "GuiDaemonClient.start_art_generation model=%s version=%s scheduler=%s steps=%s size=%sx%s",
            model,
            version,
            scheduler,
            steps,
            width,
            height,
        )
        response = self._request(
            "POST",
            "/api/v1/art/generate",
            json_payload={
                "prompt": prompt,
                "negative_prompt": negative_prompt,
                "width": width,
                "height": height,
                "steps": steps,
                "cfg_scale": cfg_scale,
                "seed": seed,
                "num_images": num_images,
                "model": model,
                "version": version,
                "scheduler": scheduler,
                "pipeline": pipeline,
                "strength": strength,
                "image_b64": image_b64,
                "skip_auto_export": skip_auto_export,
            },
            auto_start=auto_start,
            timeout_seconds=30.0,
        )
        return response.json()

    def art_job_status(
        self,
        job_id: str,
        *,
        auto_start: bool = False,
    ) -> Dict[str, Any]:
        """Return the current daemon art-job status payload."""
        response = self._request(
            "GET",
            f"/api/v1/art/status/{job_id}",
            auto_start=auto_start,
        )
        return response.json()

    def art_job_result(
        self,
        job_id: str,
        *,
        auto_start: bool = False,
    ) -> bytes:
        """Return the PNG payload for one completed daemon art job.

        Returns only the first batch image; use ``art_job_results`` for
        every checked image from a multi-image request (release D03).
        """
        response = self._request(
            "GET",
            f"/api/v1/art/result/{job_id}",
            auto_start=auto_start,
            timeout_seconds=120.0,
        )
        return response.content

    def art_job_result_at(
        self,
        job_id: str,
        index: int,
        *,
        auto_start: bool = False,
    ) -> bytes:
        """Return the PNG payload for one image of a completed batch job."""
        response = self._request(
            "GET",
            f"/api/v1/art/result/{job_id}/{index}",
            auto_start=auto_start,
            timeout_seconds=120.0,
        )
        return response.content

    def art_job_results(
        self,
        job_id: str,
        *,
        auto_start: bool = False,
    ) -> List[bytes]:
        """Return every checked image's PNG payload for a completed job.

        Uses the job status's ``image_count`` (release D03) to fetch each
        batch image individually; falls back to a single legacy image
        when the daemon reports none (an older/degraded job record).
        """
        status = self.art_job_status(job_id, auto_start=auto_start)
        image_count = int(status.get("image_count") or 0)
        if image_count <= 1:
            return [self.art_job_result(job_id, auto_start=auto_start)]
        return [
            self.art_job_result_at(job_id, index, auto_start=auto_start)
            for index in range(image_count)
        ]

    def _wait_for_art_job_completion(
        self,
        job_id: str,
        *,
        auto_start: bool,
        timeout_seconds: float,
        progress_callback: Optional[Callable[[Dict[str, Any]], None]],
    ) -> None:
        """Poll one art job until it reaches a terminal state.

        Raises RuntimeError on failure, cancellation, or timeout; returns
        normally once the job status is "completed". Shared by
        ``wait_art_job`` and ``wait_art_job_images`` so both fetch
        results (one image vs. every batch image) after the same wait.
        """
        deadline = self._time_fn() + timeout_seconds
        poll_interval = min(
            self._poll_interval_seconds,
            _ART_JOB_POLL_INTERVAL_SECONDS,
        )
        last_status: Optional[str] = None
        last_progress: Optional[float] = None
        while self._time_fn() < deadline:
            status = self.art_job_status(job_id, auto_start=auto_start)
            state = str(status.get("status", "")).lower()
            progress = float(status.get("progress") or 0.0)
            if progress_callback is not None and (
                state != last_status or progress != last_progress
            ):
                progress_callback(status)
            if state != last_status or progress != last_progress:
                self.logger.debug(
                    "GuiDaemonClient._wait_for_art_job_completion job_id=%s status=%s progress=%.1f",
                    job_id,
                    state,
                    progress,
                )
                last_status = state
                last_progress = progress
            if state == "completed":
                return
            if state == "failed":
                raise RuntimeError(
                    str(status.get("error") or "Art generation failed")
                )
            if state == "cancelled":
                raise RuntimeError("Art generation cancelled")
            self._sleep(poll_interval)
        try:
            self.cancel_art_job(job_id, auto_start=False)
        except RuntimeError:
            pass
        raise RuntimeError("Timed out waiting for art generation")

    def wait_art_job(
        self,
        job_id: str,
        *,
        auto_start: bool = False,
        timeout_seconds: float = 1800.0,
        progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> bytes:
        """Poll one art job until it completes and return the PNG bytes.

        Returns only the first batch image for compatibility with
        existing single-image callers; use ``wait_art_job_images`` to
        receive every checked image from a multi-image request.
        """
        self._wait_for_art_job_completion(
            job_id,
            auto_start=auto_start,
            timeout_seconds=timeout_seconds,
            progress_callback=progress_callback,
        )
        return self.art_job_result(job_id, auto_start=auto_start)

    def wait_art_job_images(
        self,
        job_id: str,
        *,
        auto_start: bool = False,
        timeout_seconds: float = 1800.0,
        progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> List[bytes]:
        """Poll one art job until it completes and return every batch image.

        Release issue D03: the Desktop consumer that requests
        ``num_images`` > 1 should use this instead of ``wait_art_job``,
        which only ever returns the first image.
        """
        self._wait_for_art_job_completion(
            job_id,
            auto_start=auto_start,
            timeout_seconds=timeout_seconds,
            progress_callback=progress_callback,
        )
        return self.art_job_results(job_id, auto_start=auto_start)

    def cancel_art_job(
        self,
        job_id: str,
        *,
        auto_start: bool = False,
    ) -> Dict[str, Any]:
        """Cancel one daemon-backed art job."""
        response = self._request(
            "DELETE",
            f"/api/v1/art/cancel/{job_id}",
            auto_start=auto_start,
        )
        return response.json()

    def remove_background(
        self,
        image_binary: bytes,
        *,
        auto_start: bool = True,
    ) -> bytes:
        """Run background removal through the daemon art route."""
        response = self._request(
            "POST",
            "/api/v1/art/remove-background",
            json_payload={
                "image_b64": base64.b64encode(image_binary).decode("ascii")
            },
            auto_start=auto_start,
            timeout_seconds=120.0,
        )
        return response.content

    def load_art_component(
        self,
        component: str,
        *,
        auto_start: bool = True,
    ) -> Dict[str, Any]:
        """Load one explicit art component through the daemon route."""
        response = self._request(
            "POST",
            f"/api/v1/art/components/{component}/load",
            auto_start=auto_start,
            timeout_seconds=120.0,
        )
        return response.json()

    def unload_art_component(
        self,
        component: str,
        *,
        auto_start: bool = False,
    ) -> Dict[str, Any]:
        """Unload one explicit art component through the daemon route."""
        response = self._request(
            "DELETE",
            f"/api/v1/art/components/{component}/unload",
            auto_start=auto_start,
            timeout_seconds=120.0,
        )
        return response.json()

    def start_huggingface_download(
        self,
        repo_id: str,
        *,
        model_type: str = "llm",
        output_dir: Optional[str] = None,
        missing_files: Optional[list[str]] = None,
        gguf_filename: Optional[str] = None,
        prefer_pre_quantized: bool = True,
        auto_start: bool = True,
    ) -> Dict[str, Any]:
        """Queue one daemon-backed HuggingFace download job."""
        response = self._request(
            "POST",
            "/api/v1/downloads/huggingface",
            json_payload={
                "repo_id": repo_id,
                "model_type": model_type,
                "output_dir": output_dir,
                "missing_files": missing_files,
                "gguf_filename": gguf_filename,
                "prefer_pre_quantized": prefer_pre_quantized,
            },
            auto_start=auto_start,
            timeout_seconds=30.0,
        )
        return response.json()

    def start_url_download(
        self,
        url: str,
        *,
        output_dir: str,
        filename: Optional[str] = None,
        extract_zip: bool = False,
        auto_start: bool = True,
    ) -> Dict[str, Any]:
        """Queue one daemon-backed generic URL download job."""
        response = self._request(
            "POST",
            "/api/v1/downloads/url",
            json_payload={
                "url": url,
                "output_dir": output_dir,
                "filename": filename,
                "extract_zip": extract_zip,
            },
            auto_start=auto_start,
            timeout_seconds=30.0,
        )
        return response.json()

    def download_job_status(
        self,
        job_id: str,
        *,
        auto_start: bool = False,
    ) -> Dict[str, Any]:
        """Return the current daemon-backed download job state."""
        response = self._request(
            "GET",
            f"/api/v1/downloads/status/{job_id}",
            auto_start=auto_start,
        )
        return response.json()

    def wait_download_job(
        self,
        job_id: str,
        *,
        auto_start: bool = False,
        timeout_seconds: float = 1800.0,
        progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> Dict[str, Any]:
        """Poll one download job until it reaches a terminal state."""
        deadline = self._time_fn() + timeout_seconds
        last_status: Optional[str] = None
        last_progress: Optional[float] = None
        while self._time_fn() < deadline:
            status = self.download_job_status(job_id, auto_start=auto_start)
            state = str(status.get("status", "")).lower()
            progress = float(status.get("progress") or 0.0)
            if progress_callback is not None and (
                state != last_status or progress != last_progress
            ):
                progress_callback(status)
            if state == "completed":
                return status
            if state == "failed":
                raise RuntimeError(
                    str(status.get("error") or "Download job failed")
                )
            if state == "cancelled":
                raise RuntimeError("Download job cancelled")
            last_status = state
            last_progress = progress
            self._sleep(self._poll_interval_seconds)
        try:
            self.cancel_download_job(job_id, auto_start=False)
        except RuntimeError:
            pass
        raise RuntimeError("Timed out waiting for download job")

    def cancel_download_job(
        self,
        job_id: str,
        *,
        auto_start: bool = False,
    ) -> Dict[str, Any]:
        """Cancel one daemon-backed download job."""
        response = self._request(
            "DELETE",
            f"/api/v1/downloads/cancel/{job_id}",
            auto_start=auto_start,
        )
        return response.json()

    def transcribe_audio(
        self,
        audio_bytes: bytes,
        *,
        mime_type: str = "application/octet-stream",
        auto_start: bool = True,
    ) -> Dict[str, Any]:
        """Submit one STT transcription request through the daemon API."""
        response = self._request(
            "POST",
            "/api/v1/stt/transcribe",
            files={
                "audio": (
                    "audio.bin",
                    audio_bytes,
                    mime_type,
                )
            },
            auto_start=auto_start,
            timeout_seconds=120.0,
        )
        return response.json()

    def load_runtime(
        self,
        runtime_name: str,
        *,
        provider: str = "local",
        deployment_mode: str = "default",
        request_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        auto_start: bool = True,
        timeout_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Load one runtime through the daemon control API."""
        return self._runtime_action(
            runtime_name,
            "load",
            provider=provider,
            deployment_mode=deployment_mode,
            request_id=request_id,
            metadata=metadata,
            auto_start=auto_start,
            timeout_seconds=timeout_seconds,
        )

    def unload_runtime(
        self,
        runtime_name: str,
        *,
        provider: str = "local",
        deployment_mode: str = "default",
        request_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        auto_start: bool = True,
        timeout_seconds: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Unload one runtime through the daemon control API."""
        return self._runtime_action(
            runtime_name,
            "unload",
            provider=provider,
            deployment_mode=deployment_mode,
            request_id=request_id,
            metadata=metadata,
            auto_start=auto_start,
            timeout_seconds=timeout_seconds,
        )

    def stream_llm_request(
        self,
        prompt: str,
        llm_request: "LLMRequest",
        action: LLMActionType,
        request_id: str,
        *,
        search_hints: Optional[Dict[str, Any]] = None,
        conversation_id: Optional[int] = None,
        node_id: Optional[str] = None,
    ) -> Iterable[Dict[str, Any]]:
        """Yield NDJSON chunks from the daemon's legacy LLM endpoint."""
        headers = {"x-request-id": request_id}
        with self._request(
            "POST",
            "/llm/generate",
            json_payload=self._llm_payload(
                prompt,
                llm_request,
                action,
                search_hints=search_hints,
                conversation_id=conversation_id,
                node_id=node_id,
            ),
            headers=headers,
            stream=True,
        ) as response:
            for line in response.iter_lines(chunk_size=1):
                if not line:
                    continue
                yield json.loads(line.decode("utf-8"))

    def list_conversations(
        self,
        *,
        limit: int = 50,
        auto_start: bool = False,
    ) -> list[Dict[str, Any]]:
        """Return serialized conversation metadata from the daemon."""
        query = urlencode({"limit": limit})
        response = self._request(
            "GET",
            f"/api/v1/llm/conversations?{query}",
            auto_start=auto_start,
        )
        return list(response.json().get("conversations") or [])

    def get_conversation_session(
        self,
        *,
        conversation_id: Optional[int] = None,
        max_messages: int = 50,
        auto_start: bool = False,
    ) -> Dict[str, Any]:
        """Return one serialized conversation session from the daemon."""
        query = {"max_messages": max_messages}
        if conversation_id is not None:
            query["conversation_id"] = conversation_id
        response = self._request(
            "GET",
            f"/api/v1/llm/conversations/session?{urlencode(query)}",
            auto_start=auto_start,
        )
        return response.json()

    def select_conversation(
        self,
        conversation_id: int,
        *,
        max_messages: int = 50,
        auto_start: bool = False,
    ) -> Dict[str, Any]:
        """Select one daemon-side conversation and return the session payload."""
        response = self._request(
            "POST",
            "/api/v1/llm/conversations/select",
            json_payload={
                "conversation_id": conversation_id,
                "max_messages": max_messages,
            },
            auto_start=auto_start,
        )
        return response.json()

    def summarize_conversation(
        self,
        conversation_id: int,
        *,
        auto_start: bool = False,
    ) -> Dict[str, Any]:
        """Return one daemon-generated summary payload for a conversation."""
        response = self._request(
            "GET",
            f"/api/v1/llm/conversations/{conversation_id}/summary",
            auto_start=auto_start,
        )
        return response.json()

    def delete_conversation(
        self,
        conversation_id: int,
        *,
        auto_start: bool = False,
    ) -> Dict[str, Any]:
        """Delete one conversation through the daemon conversation API."""
        response = self._request(
            "DELETE",
            f"/api/v1/llm/conversations/{conversation_id}",
            auto_start=auto_start,
        )
        return response.json()

    # ------------------------------------------------------------------
    # Signal adapter handlers
    # ------------------------------------------------------------------

    @property
    def signal_handlers(
        self,
    ) -> Dict[Any, Callable[[Dict[str, Any]], None]]:
        """Return the signal-to-API handler mapping."""
        return {
            SignalCode.DO_GENERATE_SIGNAL: self._on_do_generate,
            SignalCode.AUDIO_CAPTURE_WORKER_RESPONSE_SIGNAL: (
                self._on_stt_transcribe
            ),
            SignalCode.INTERRUPT_IMAGE_GENERATION_SIGNAL: (
                self._on_interrupt_image_generation
            ),
            SignalCode.INTERRUPT_PROCESS_SIGNAL: (
                self._on_interrupt_process
            ),
            SignalCode.SD_LOAD_SIGNAL: self._on_load_art,
            SignalCode.SD_UNLOAD_SIGNAL: self._on_unload_art,
            SignalCode.LLM_LOAD_SIGNAL: self._on_llm_load,
            SignalCode.LLM_UNLOAD_SIGNAL: self._on_llm_unload,
            SignalCode.STT_LOAD_SIGNAL: self._on_stt_load,
            SignalCode.STT_UNLOAD_SIGNAL: self._on_stt_unload,
        }

    def _on_do_generate(self, data: Dict[str, Any]) -> None:
        self.logger.debug("Routing DO_GENERATE_SIGNAL to daemon")
        self.generate_image_async(data)

    def _on_interrupt_image_generation(
        self, data: Dict[str, Any]
    ) -> None:
        job_id = data.get("job_id", "")
        if job_id:
            self.cancel_generation(job_id)

    def _on_interrupt_process(self, _data: Dict[str, Any]) -> None:
        self.interrupt_llm()

    def _on_stt_transcribe(self, data: Dict[str, Any]) -> None:
        audio_bytes = data.get("audio_bytes")
        if audio_bytes:
            result = self.transcribe_audio(
                audio_bytes,
                mime_type=str(
                    data.get("mime_type") or "application/octet-stream",
                ),
            )
            transcription = str(result.get("text", "") or "")
            if transcription:
                self._emit(
                    SignalCode.AUDIO_PROCESSOR_RESPONSE_SIGNAL,
                    {
                        "transcription": transcription,
                        "language": result.get("language"),
                    },
                )

    def _on_load_art(self, _data: Dict[str, Any]) -> None:
        self.load_runtime("art", deployment_mode="sidecar")

    def _on_unload_art(self, _data: Dict[str, Any]) -> None:
        self.unload_runtime("art", deployment_mode="sidecar")

    def _on_llm_load(self, _data: Dict[str, Any]) -> None:
        self.load_runtime("llm")

    def _on_llm_unload(self, _data: Dict[str, Any]) -> None:
        self.unload_runtime("llm")

    def _on_stt_load(self, _data: Dict[str, Any]) -> None:
        self.load_runtime("stt", deployment_mode="sidecar")

    def _on_stt_unload(self, _data: Dict[str, Any]) -> None:
        self.unload_runtime("stt", deployment_mode="sidecar")

    def _resolved_auto_start(self, auto_start: Optional[bool]) -> bool:
        """Return the effective auto-start behavior for this call."""
        if auto_start is None:
            return self._auto_start
        return auto_start

    def _prepare_connection_attempt(self) -> None:
        """Set the state for a new connection attempt."""
        if self._state is DaemonConnectionState.NOT_STARTED:
            self._set_state(DaemonConnectionState.CONNECTING, "starting daemon")
            return
        self._set_state(DaemonConnectionState.RECONNECTING, "starting daemon")

    def _wait_until_ready(self) -> bool:
        """Wait for the daemon health endpoint to become ready."""
        deadline = self._time_fn() + self._startup_timeout_seconds
        while self._time_fn() < deadline:
            exit_code = self._launcher.last_exit_code()
            if exit_code is not None:
                self._last_error = (
                    "Daemon process exited early with code "
                    f"{exit_code}"
                )
                self._set_state(DaemonConnectionState.FAILED, self._last_error)
                return False
            health = self._healthcheck_payload()
            if health is not None:
                mismatch = self._contract_version_mismatch_reason(health)
                if mismatch is not None:
                    self._last_error = mismatch
                    self._set_state(DaemonConnectionState.FAILED, mismatch)
                    return False
                if self._stale_dev_daemon_reason(health) is None:
                    self._set_state(
                        DaemonConnectionState.CONNECTED, "connected"
                    )
                    return True
            self._sleep(self._poll_interval_seconds)

        self._last_error = "Timed out waiting for daemon to become ready"
        self._set_state(DaemonConnectionState.FAILED, self._last_error)
        return False

    def _healthcheck_payload(
        self, *, timeout_seconds: float = 5.0
    ) -> Optional[Dict[str, Any]]:
        """Return the daemon /health payload when it is reachable."""
        try:
            response = self._session.request(
                "GET",
                f"{self.base_url}/health",
                headers=self._loopback_headers(),
                timeout=timeout_seconds,
            )
            response.raise_for_status()
            return response.json()
        except requests.RequestException as exc:
            self._last_error = str(exc)
            return None

    def _loopback_headers(self) -> Dict[str, str]:
        """Return the per-user loopback token header for daemon requests."""
        return {"X-Airunner-Token": self._loopback_token}

    def _expected_dev_build_token(self) -> Optional[str]:
        """Return the current expected dev build token for this client."""
        if not self._detect_stale_dev_daemon:
            return None
        now = self._time_fn()
        if now - self._dev_build_token_checked_at < 2.0:
            return self._cached_dev_build_token
        self._cached_dev_build_token = current_dev_build_token()
        self._dev_build_token_checked_at = now
        return self._cached_dev_build_token

    def _stale_dev_daemon_reason(
        self,
        health: Optional[Dict[str, Any]],
    ) -> Optional[str]:
        """Return a mismatch reason when a dev daemon is stale."""
        expected = self._expected_dev_build_token()
        if health is None or not expected:
            return None
        observed = str(health.get("dev_build_token") or "").strip()
        if not observed:
            if not self._missing_dev_build_token_logged:
                self.logger.debug(
                    "Daemon health payload missing dev_build_token; "
                    "skipping stale-daemon recycle"
                )
                self._missing_dev_build_token_logged = True
            return None
        self._missing_dev_build_token_logged = False
        if observed != expected:
            return "stale dev daemon build token mismatch"
        return None

    def _contract_version_mismatch_reason(
        self,
        health: Optional[Dict[str, Any]],
    ) -> Optional[str]:
        """Return a mismatch reason when the daemon's wire contract
        version is incompatible with this client's (issue #2192).

        Unlike a stale dev daemon, this is never resolved by recycling
        the daemon process: an incompatible pair is a genuinely
        different daemon build, and restarting it changes nothing.
        Callers must treat a non-None reason as a hard failure, not a
        recycle-and-retry condition.
        """
        if health is None:
            return None
        remote_version = health.get("contract_version")
        if not remote_version:
            # A daemon build old enough to predate this field cannot
            # be assumed compatible; fail closed rather than guess.
            return (
                "daemon health payload has no contract_version "
                f"(expected {CONTRACT_VERSION})"
            )
        if is_compatible_contract_version(CONTRACT_VERSION, remote_version):
            return None
        return (
            f"desktop contract version {CONTRACT_VERSION} is "
            f"incompatible with daemon contract version {remote_version}"
        )

    def _recycle_stale_daemon(self, reason: str) -> bool:
        """Stop one stale local daemon so a fresh one can be launched."""
        self.logger.info("Recycling daemon: %s", reason)
        self._request_daemon_shutdown()
        if not self._wait_until_unavailable(5.0):
            self._terminate_port_owner()
        if self._wait_until_unavailable(5.0):
            self._set_state(DaemonConnectionState.RECONNECTING, reason)
            return True
        self._last_error = "Timed out stopping stale daemon"
        self._set_state(DaemonConnectionState.FAILED, self._last_error)
        return False

    def _request_daemon_shutdown(self) -> None:
        """Ask a reachable daemon on this port to shut itself down."""
        try:
            response = self._session.request(
                "POST",
                f"{self.base_url}/admin/shutdown",
                headers=self._loopback_headers(),
                timeout=5,
            )
            response.raise_for_status()
        except requests.RequestException:
            self.logger.debug("Daemon shutdown request failed", exc_info=True)

    def _wait_until_unavailable(self, timeout_seconds: float) -> bool:
        """Return True once the daemon no longer answers /health."""
        deadline = self._time_fn() + timeout_seconds
        while self._time_fn() < deadline:
            if self._healthcheck_payload() is None:
                return True
            self._sleep(self._poll_interval_seconds)
        return False

    def _terminate_port_owner(self) -> None:
        """Send SIGTERM to any process listening on the configured port."""
        port = self.config.config.get("server", {}).get("port", 8188)
        for pid in self._pids_on_port(port):
            try:
                os.kill(pid, signal.SIGTERM)
            except OSError:
                self.logger.debug("Failed to terminate pid=%s", pid)

    def _pids_on_port(self, port: int) -> list[int]:
        """Return process ids currently listening on one TCP port."""
        try:
            result = subprocess.run(
                ["lsof", "-ti", f":{port}"],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
        except (FileNotFoundError, subprocess.SubprocessError):
            return []
        return [int(pid) for pid in result.stdout.split() if pid.isdigit()]

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_payload: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        stream: bool = False,
        auto_start: bool = True,
        timeout_seconds: Optional[float] = None,
    ) -> requests.Response:
        """Perform an HTTP request against the daemon."""
        if not self.ensure_connected(auto_start=auto_start):
            raise RuntimeError(self._last_error or "daemon unavailable")

        request_headers = self._loopback_headers()
        if headers:
            request_headers.update(headers)
        try:
            response = self._session.request(
                method,
                f"{self.base_url}{path}",
                json=json_payload,
                files=files,
                headers=request_headers,
                stream=stream,
                timeout=timeout_seconds or self._request_timeout_seconds,
            )
            response.raise_for_status()
            self._set_state(DaemonConnectionState.CONNECTED, "connected")
            return response
        except requests.RequestException as exc:
            self._last_error = str(exc)
            self._set_state(DaemonConnectionState.DISCONNECTED, self._last_error)
            raise RuntimeError(self._last_error) from exc

    def _runtime_action(
        self,
        runtime_name: str,
        action: str,
        *,
        provider: str,
        deployment_mode: str,
        request_id: Optional[str],
        metadata: Optional[Dict[str, Any]],
        auto_start: bool,
        timeout_seconds: Optional[float],
    ) -> Dict[str, Any]:
        """Call one daemon runtime control endpoint and return its payload."""
        response = self._request(
            "POST",
            f"/api/v1/daemon/runtimes/{runtime_name}/{action}",
            json_payload={
                "provider": provider,
                "deployment_mode": deployment_mode,
                "request_id": request_id,
                "metadata": metadata or {},
            },
            auto_start=auto_start,
            timeout_seconds=timeout_seconds,
        )
        return response.json()

    @staticmethod
    def _runtime_matches(summary: Dict[str, Any], loaded: bool) -> bool:
        """Return True when one runtime summary matches the target state."""
        summary_loaded = bool(summary.get("loaded"))
        summary_status = str(summary.get("status", "")).lower()
        if loaded:
            return summary_loaded and summary_status == "ready"
        return not summary_loaded

    def _set_state(self, state: DaemonConnectionState, details: str) -> None:
        """Update the tracked daemon connection state."""
        self._state = state
        if state in {
            DaemonConnectionState.DISCONNECTED,
            DaemonConnectionState.FAILED,
        }:
            self._last_error = details
        if self._state_callback is not None:
            self._state_callback(state, details)

    @staticmethod
    def _llm_payload(
        prompt: str,
        llm_request: "LLMRequest",
        action: LLMActionType,
        *,
        search_hints: Optional[Dict[str, Any]],
        conversation_id: Optional[int],
        node_id: Optional[str],
    ) -> Dict[str, Any]:
        """Build the legacy daemon payload from an LLM request object."""
        payload = {
            "prompt": prompt,
            "action": action.name,
            "stream": True,
        }
        payload.update(GuiDaemonClient._llm_request_fields(llm_request))
        if search_hints is not None:
            payload["search_hints"] = search_hints
        if conversation_id is not None:
            payload["conversation_id"] = conversation_id
        if node_id is not None:
            payload["node_id"] = node_id
        return payload

    @staticmethod
    def _llm_request_fields(llm_request: "LLMRequest") -> Dict[str, Any]:
        """Return JSON-safe fields that the daemon legacy route understands."""
        payload = llm_request.to_dict()
        extra_fields = {
            "model_service": llm_request.model_service,
            "api_model": llm_request.api_model,
            "dtype": llm_request.dtype,
            "use_memory": llm_request.use_memory,
            "tool_categories": llm_request.tool_categories,
            "system_prompt": llm_request.system_prompt,
            "response_format": llm_request.response_format,
            "rag_files": llm_request.rag_files,
            "ephemeral_conversation": llm_request.ephemeral_conversation,
            "enable_thinking": llm_request.enable_thinking,
            "model": llm_request.model,
            "force_tool": llm_request.force_tool,
            "include_mood": llm_request.include_mood,
            "include_datetime": llm_request.include_datetime,
            "include_style": llm_request.include_style,
            "include_memory": llm_request.include_memory,
            "include_ui_context": llm_request.include_ui_context,
        }
        for key, value in extra_fields.items():
            if value is not None:
                payload[key] = value
        return payload