"""Initial migration

Revision ID: 181e31f78151
Revises: None
Create Date: 2025-03-06 19:37:44.523586

"""

from typing import Sequence, Union

from alembic import op

from airunner_services.database.base import Base


# revision identifiers, used by Alembic.
revision: str = "181e31f78151"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create tables using models
    Base.metadata.create_all(bind=op.get_bind())


def downgrade() -> None:
    # Drop tables using models
    Base.metadata.drop_all(bind=op.get_bind())
