"""Shared bootstrap data for LLM model file requirements."""

from __future__ import annotations


LLM_FILE_BOOTSTRAP_DATA = {
    "unsloth/Qwen3.5-9B-GGUF": {
        "path_settings": "llm_causallm_model_path",
        "context_length": 262144,
        "native_context_length": 262144,
        "yarn_max_context_length": 262144,
        "capabilities": {
            "function_calling": True,
            "thinking_capable": True,
            "rag_capable": True,
            "vision_capable": False,
            "code_capable": True,
            "is_embedding_model": False,
        },
        "files": {
            "Qwen3.5-9B-Q8_0.gguf": 9527502048,
        },
    },
    "unsloth/gpt-oss-20b-GGUF": {
        "path_settings": "llm_causallm_model_path",
        "context_length": 131072,
        "native_context_length": 4096,
        "yarn_max_context_length": 131072,
        "capabilities": {
            "function_calling": False,
            "thinking_capable": False,
            "rag_capable": True,
            "vision_capable": False,
            "code_capable": True,
            "is_embedding_model": False,
        },
        "files": {
            "gpt-oss-20b-F16.gguf": 13792639168,
        },
    },
    "Qwen/Qwen2.5-Coder-7B-Instruct-GGUF": {
        "path_settings": "llm_causallm_model_path",
        "context_length": 131072,
        "capabilities": {
            "function_calling": True,
            "thinking_capable": False,
            "rag_capable": True,
            "vision_capable": False,
            "code_capable": True,
            "is_embedding_model": False,
        },
        "files": {
            "qwen2.5-coder-7b-instruct-q4_k_m.gguf": 4876509632,
        },
    },
    "CohereForAI/c4ai-command-r-08-2024": {
        "path_settings": "llm_causallm_model_path",
        "context_length": 131072,
        "capabilities": {
            "function_calling": True,
            "thinking_capable": False,
            "rag_capable": True,
            "vision_capable": False,
            "code_capable": True,
            "is_embedding_model": False,
        },
        "files": {
            "config.json": 639,
            "generation_config.json": 137,
            "model-00001-of-00014.safetensors": 4898947792,
            "model-00002-of-00014.safetensors": 4932553528,
            "model-00003-of-00014.safetensors": 4932570024,
            "model-00004-of-00014.safetensors": 4831890592,
            "model-00005-of-00014.safetensors": 4932553560,
            "model-00006-of-00014.safetensors": 4932553552,
            "model-00007-of-00014.safetensors": 4932570048,
            "model-00008-of-00014.safetensors": 4831890616,
            "model-00009-of-00014.safetensors": 4932553560,
            "model-00010-of-00014.safetensors": 4932553552,
            "model-00011-of-00014.safetensors": 4932570048,
            "model-00012-of-00014.safetensors": 4831890616,
            "model-00013-of-00014.safetensors": 4932553560,
            "model-00014-of-00014.safetensors": 805339584,
            "model.safetensors.index.json": 26206,
            "special_tokens_map.json": 439,
            "tokenizer.json": 12778456,
            "tokenizer_config.json": 21742,
        },
    },
    "sentence-transformers/sentence-t5-large": {
        "path_settings": "sentence_transformers_path",
        "context_length": 512,
        "capabilities": {
            "function_calling": False,
            "thinking_capable": False,
            "rag_capable": False,
            "vision_capable": False,
            "code_capable": False,
            "is_embedding_model": True,
        },
        "files": {
            "1_Pooling/config.json": 190,
            "2_Dense/config.json": 116,
            "2_Dense/model.safetensors": 3145848,
            "config.json": 1388,
            "config_sentence_transformers.json": 122,
            "model.safetensors": 669902800,
            "modules.json": 461,
            "sentence_bert_config.json": 53,
            "special_tokens_map.json": 1786,
            "spiece.model": 791656,
            "tokenizer.json": 1387554,
            "tokenizer_config.json": 1924,
        },
    },
    "intfloat/e5-large": {
        "path_settings": "text_embedding",
        "context_length": 512,
        "capabilities": {
            "function_calling": False,
            "thinking_capable": False,
            "rag_capable": False,
            "vision_capable": False,
            "code_capable": False,
            "is_embedding_model": True,
        },
        "files": {
            "1_Pooling/config.json": 201,
            "config.json": 611,
            "model.safetensors": 1340616616,
            "modules.json": 387,
            "sentence_bert_config.json": 57,
            "special_tokens_map.json": 112,
            "tokenizer.json": 466081,
            "tokenizer_config.json": 385,
            "vocab.txt": 231508,
        },
    },
}


__all__ = ["LLM_FILE_BOOTSTRAP_DATA"]