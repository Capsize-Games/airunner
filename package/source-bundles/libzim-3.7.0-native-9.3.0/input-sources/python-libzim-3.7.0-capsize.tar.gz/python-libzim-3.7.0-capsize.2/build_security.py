"""Helpers for validating native libzim build inputs before use."""

from __future__ import annotations

import hashlib
import os
import re
import tempfile
import urllib.parse
import urllib.request
from pathlib import Path


KNOWN_ARCHIVE_SHA256 = {
    "libzim_linux-x86_64-manylinux-9.3.0-1.tar.gz": (
        "01cf3960645ad481a1831c0537887eeee30d0357d27996b1740e2ef77650947c"
    ),
}


def expected_archive_sha256(filename: str, override: str | None = None) -> str:
    """Return the reviewed digest for a filename or a caller-pinned digest."""
    value = KNOWN_ARCHIVE_SHA256.get(filename) or override
    if value is None:
        raise ValueError(f"No reviewed SHA-256 configured for LIBZIM archive {filename}")
    return _validate_sha256(value)


def _validate_sha256(value: str) -> str:
    if not re.fullmatch(r"[0-9a-f]{64}", value):
        raise ValueError("LIBZIM archive SHA-256 must be 64 lowercase hexadecimal characters")
    return value


def _digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def download_verified_archive(url: str, destination: Path, expected_sha256: str) -> Path:
    """Download only HTTPS archives and verify before replacing the destination."""
    expected_sha256 = _validate_sha256(expected_sha256)
    if urllib.parse.urlsplit(url).scheme != "https":
        raise ValueError("LIBZIM archive downloads require HTTPS")

    destination = Path(destination)
    if destination.is_file():
        actual_sha256 = _digest(destination)
        if actual_sha256 != expected_sha256:
            raise ValueError(f"Existing LIBZIM archive hash mismatch: {destination.name}")
        return destination

    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(prefix=f".{destination.name}.", dir=destination.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "wb") as output, urllib.request.urlopen(
            url, timeout=60
        ) as response:
            while block := response.read(1024 * 1024):
                output.write(block)
        actual_sha256 = _digest(temporary)
        if actual_sha256 != expected_sha256:
            raise ValueError(f"Downloaded LIBZIM archive hash mismatch: {destination.name}")
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
    return destination
