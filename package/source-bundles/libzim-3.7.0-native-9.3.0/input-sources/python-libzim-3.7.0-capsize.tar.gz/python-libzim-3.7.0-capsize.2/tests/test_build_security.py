import hashlib
from pathlib import Path

import pytest

from build_security import download_verified_archive, expected_archive_sha256


def test_selected_linux_archive_has_reviewed_hash():
    assert expected_archive_sha256(
        "libzim_linux-x86_64-manylinux-9.3.0-1.tar.gz"
    ) == "01cf3960645ad481a1831c0537887eeee30d0357d27996b1740e2ef77650947c"


def test_unreviewed_archive_requires_explicit_hash():
    with pytest.raises(ValueError, match="No reviewed SHA-256"):
        expected_archive_sha256("libzim_linux-aarch64-manylinux-9.3.0-1.tar.gz")


def test_download_helper_rejects_non_https_before_network(tmp_path: Path):
    with pytest.raises(ValueError, match="require HTTPS"):
        download_verified_archive(
            "http://example.invalid/archive.tar.gz",
            tmp_path / "archive.tar.gz",
            "0" * 64,
        )


def test_existing_archive_must_match_expected_hash(tmp_path: Path):
    archive = tmp_path / "archive.tar.gz"
    archive.write_bytes(b"source archive")
    expected = hashlib.sha256(b"source archive").hexdigest()

    assert download_verified_archive(
        "https://example.invalid/archive.tar.gz", archive, expected
    ) == archive
    with pytest.raises(ValueError, match="Existing LIBZIM archive hash mismatch"):
        download_verified_archive(
            "https://example.invalid/archive.tar.gz", archive, "0" * 64
        )


def test_hash_value_must_be_canonical_sha256():
    with pytest.raises(ValueError, match="64 lowercase hexadecimal"):
        expected_archive_sha256("unreviewed.tar.gz", "A" * 64)
